 /* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
 /*
  * Copyright (c) 2004 Francisco J. Ros
  * Copyright (c) 2007 INESC Porto
  *
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License version 2 as
  * published by the Free Software Foundation;
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  *
  * Authors: Francisco J. Ros  <fjrm@dif.um.es>
  *          Gustavo J. A. M. Carneiro <gjc@inescporto.pt>
  */
 
 
 #include "olsr-state.h"
 #include "math.h"
 
 
 namespace ns3 {
 namespace olsr {
 
 /********** MPR Selector Set Manipulation **********/
 
 MprSelectorTuple*
 OlsrState::FindMprSelectorTuple (Ipv4Address const &mainAddr)
 {
   for (MprSelectorSet::iterator it = m_mprSelectorSet.begin ();
        it != m_mprSelectorSet.end (); it++)
     {
       if (it->mainAddr == mainAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseMprSelectorTuple (const MprSelectorTuple &tuple)
 {
   for (MprSelectorSet::iterator it = m_mprSelectorSet.begin ();
        it != m_mprSelectorSet.end (); it++)
     {
       if (*it == tuple)
         {
           m_mprSelectorSet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::EraseMprSelectorTuples (const Ipv4Address &mainAddr)
 {
   for (MprSelectorSet::iterator it = m_mprSelectorSet.begin ();
        it != m_mprSelectorSet.end (); )
     {
       if (it->mainAddr == mainAddr)
         {
           it = m_mprSelectorSet.erase (it);
         }
       else
         {
           it++;
         }
     }
 }
 
 void
 OlsrState::InsertMprSelectorTuple (MprSelectorTuple const &tuple)
 {
   m_mprSelectorSet.push_back (tuple);
 }
 
 std::string
 OlsrState::PrintMprSelectorSet () const
 {
   std::ostringstream os;
   os << "[";
   for (MprSelectorSet::const_iterator iter = m_mprSelectorSet.begin ();
        iter != m_mprSelectorSet.end (); iter++)
     {
       MprSelectorSet::const_iterator next = iter;
       next++;
       os << iter->mainAddr;
       if (next != m_mprSelectorSet.end ())
         {
           os << ", ";
         }
     }
   os << "]";
   return os.str ();
 }
 
 
 /********** Neighbor Set Manipulation **********/
 
 NeighborTuple*
 OlsrState::FindNeighborTuple (Ipv4Address const &mainAddr)
 {
   for (NeighborSet::iterator it = m_neighborSet.begin ();
        it != m_neighborSet.end (); it++)
     {
       if (it->neighborMainAddr == mainAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 const NeighborTuple*
 OlsrState::FindSymNeighborTuple (Ipv4Address const &mainAddr) const
 {
   for (NeighborSet::const_iterator it = m_neighborSet.begin ();
        it != m_neighborSet.end (); it++)
     {
       if (it->neighborMainAddr == mainAddr && it->status == NeighborTuple::STATUS_SYM)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 NeighborTuple*
 OlsrState::FindNeighborTuple (Ipv4Address const &mainAddr, uint8_t willingness)
 {
   for (NeighborSet::iterator it = m_neighborSet.begin ();
        it != m_neighborSet.end (); it++)
     {
       if (it->neighborMainAddr == mainAddr && it->willingness == willingness)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseNeighborTuple (const NeighborTuple &tuple)
 {
   for (NeighborSet::iterator it = m_neighborSet.begin ();
        it != m_neighborSet.end (); it++)
     {
       if (*it == tuple)
         {
           m_neighborSet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::EraseNeighborTuple (const Ipv4Address &mainAddr)
 {
   for (NeighborSet::iterator it = m_neighborSet.begin ();
        it != m_neighborSet.end (); it++)
     {
       if (it->neighborMainAddr == mainAddr)
         {
           it = m_neighborSet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::InsertNeighborTuple (NeighborTuple const &tuple)
 {
   for (NeighborSet::iterator it = m_neighborSet.begin ();
        it != m_neighborSet.end (); it++)
     {
       if (it->neighborMainAddr == tuple.neighborMainAddr)
         {
           // Update it
           *it = tuple;
           return;
         }
     }
   m_neighborSet.push_back (tuple);
 }

//-----------------------------------------------------------------------s----------------------------------------------------------
 //dest tuple manipulation
 void
 OlsrState::InsertDestTuple (DestTuple const &destTuple)
 {
   for (DestSet::iterator it = m_destSet.begin ();
        it != m_destSet.end (); it++)
     {
       if (it->destAddr == destTuple.destAddr)
         {
           // Update it
           *it = destTuple;//std::cout<<"dest tuple updated " << std::endl;
           return;
         }
     }
   m_destSet.push_back (destTuple);//std::cout<<"dest tuple pushed " << std::endl;
 }

 DestTuple*
 OlsrState::FindDestTuple (Ipv4Address const &dAddr)
 {
   for (DestSet::iterator it = m_destSet.begin ();
        it != m_destSet.end (); it++)
     {
       if (it->destAddr == dAddr)
         {
          return &(*it);
         }
     }
   return NULL;
 }

 // mpr tuple manipulation
 void
 OlsrState::InsertMpr_Tuple (const Mpr_Tuple &mpr_tuple)
 {
   for (Mpr_Set::iterator it = m_mpr_set.begin ();
        it != m_mpr_set.end (); it++)
     {
       if ((it->mt_dest == mpr_tuple.mt_dest) && (it->mt_selector == mpr_tuple.mt_selector) )
         {
           // Update it
           *it = mpr_tuple;//std::cout<<"mpr tuple updated " << std::endl;
           return;
        }
     }
   m_mpr_set.push_back (mpr_tuple);//std::cout<<"mpr tuple pushed " << std::endl;
 }

 Mpr_Tuple*
 OlsrState::FindMpr_Tuple (const Ipv4Address &dAddr)
 {
   for (Mpr_Set::iterator it = m_mpr_set.begin ();
        it != m_mpr_set.end (); it++)
     {
       if (it->mt_dest == dAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 } 

// cost tuple manipulation
 void
 OlsrState::InsertCostTuple (const CostTuple &costTuple)
 {
   for (CostSet::iterator it = m_costSet.begin ();
        it != m_costSet.end (); it++)
     {
       if ((it->ct_dest == costTuple.ct_dest) && (it->ct_nextMpr == costTuple.ct_nextMpr))
         {
           // Update it
           *it = costTuple;//std::cout<<"cost tuple updated " << std::endl;
           return;
        }
     }
   m_costSet.push_back (costTuple);//std::cout<<"cost tuple pushed " << std::endl;
 }

 CostTuple*
 OlsrState::FindCostTuple (const Ipv4Address &dAddr)
 {
   for (CostSet::iterator it = m_costSet.begin ();
        it != m_costSet.end (); it++)
     {
       if (it->ct_dest == dAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 } 

 void
 OlsrState::EraseCostTuple (const CostTuple &tuple)
 {
   for (CostSet::iterator it = m_costSet.begin ();
        it != m_costSet.end (); it++)
     {
       if (it->ct_dest == tuple.ct_dest)
         {
           m_costSet.erase (it);
           break;
         }
     }
 }

//A* algorithm
 void 
 OlsrState::aStar()
 {  
    for (Mpr_Set::iterator it1 = m_mpr_set.begin ();
       it1 != m_mpr_set.end (); it1++)
    {
        uint16_t dist,dist_min = 10000;
        Ipv4Address addrs_next;
        for (NeighborSet::iterator it2 = m_neighborSet.begin ();
           it2 != m_neighborSet.end (); it2++)
         {
         dist = it1->mt_ch_cost + it2->ch_cost + (sqrt(pow(((it1->mt_locationX)-(it2->locX)),2)+pow(((it1->mt_locationY)-(it2->locY)),2)))/5;
         if(dist < dist_min)
            {
              dist_min = dist;
              addrs_next = it2->neighborMainAddr;
            }
         }
      CostTuple t;
      t.ct_dest = it1->mt_dest ;  
      t.ct_nextMpr = addrs_next;  
      t.ct_cost = dist_min; //std::cout<<dist_min<<std::endl;
      OlsrState::EraseCostTuple(t);//erasing previous cost tuple.
      OlsrState::InsertCostTuple (t);
    }
 }
 
//-----------------------------------------------------------------------e----------------------------------------------------------
 
 /********** Neighbor 2 Hop Set Manipulation **********/
 
 TwoHopNeighborTuple*
 OlsrState::FindTwoHopNeighborTuple (Ipv4Address const &neighborMainAddr,
                                     Ipv4Address const &twoHopNeighborAddr)
 {
   for (TwoHopNeighborSet::iterator it = m_twoHopNeighborSet.begin ();
        it != m_twoHopNeighborSet.end (); it++)
     {
       if (it->neighborMainAddr == neighborMainAddr
           && it->twoHopNeighborAddr == twoHopNeighborAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseTwoHopNeighborTuple (const TwoHopNeighborTuple &tuple)
 {
   for (TwoHopNeighborSet::iterator it = m_twoHopNeighborSet.begin ();
        it != m_twoHopNeighborSet.end (); it++)
     {
       if (*it == tuple)
         {
           m_twoHopNeighborSet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::EraseTwoHopNeighborTuples (const Ipv4Address &neighborMainAddr,
                                       const Ipv4Address &twoHopNeighborAddr)
 {
   for (TwoHopNeighborSet::iterator it = m_twoHopNeighborSet.begin ();
        it != m_twoHopNeighborSet.end (); )
     {
       if (it->neighborMainAddr == neighborMainAddr
           && it->twoHopNeighborAddr == twoHopNeighborAddr)
         {
           it = m_twoHopNeighborSet.erase (it);
         }
       else
         {
           it++;
         }
     }
 }
 
 void
 OlsrState::EraseTwoHopNeighborTuples (const Ipv4Address &neighborMainAddr)
 {
   for (TwoHopNeighborSet::iterator it = m_twoHopNeighborSet.begin ();
        it != m_twoHopNeighborSet.end (); )
     {
       if (it->neighborMainAddr == neighborMainAddr)
         {
           it = m_twoHopNeighborSet.erase (it);
         }
       else
         {
           it++;
         }
     }
 }
 
 void
 OlsrState::InsertTwoHopNeighborTuple (TwoHopNeighborTuple const &tuple)
 {
   m_twoHopNeighborSet.push_back (tuple);
 }
 
 /********** MPR Set Manipulation **********/
 
 bool
 OlsrState::FindMprAddress (Ipv4Address const &addr)
 {
   MprSet::iterator it = m_mprSet.find (addr);
   return (it != m_mprSet.end ());
 }
 
 void
 OlsrState::SetMprSet (MprSet mprSet)
 {
   m_mprSet = mprSet;
 }
 MprSet
 OlsrState::GetMprSet () const
 {
   return m_mprSet;
 }
 
 /********** Duplicate Set Manipulation **********/
 
 DuplicateTuple*
 OlsrState::FindDuplicateTuple (Ipv4Address const &addr, uint16_t sequenceNumber)
 {
   for (DuplicateSet::iterator it = m_duplicateSet.begin ();
        it != m_duplicateSet.end (); it++)
     {
       if (it->address == addr && it->sequenceNumber == sequenceNumber)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseDuplicateTuple (const DuplicateTuple &tuple)
 {
   for (DuplicateSet::iterator it = m_duplicateSet.begin ();
        it != m_duplicateSet.end (); it++)
     {
       if (*it == tuple)
         {
           m_duplicateSet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::InsertDuplicateTuple (DuplicateTuple const &tuple)
 {
   m_duplicateSet.push_back (tuple);
 }
 
 /********** Link Set Manipulation **********/
 
 LinkTuple*
 OlsrState::FindLinkTuple (Ipv4Address const & ifaceAddr)
 {
   for (LinkSet::iterator it = m_linkSet.begin ();
        it != m_linkSet.end (); it++)
     {
       if (it->neighborIfaceAddr == ifaceAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 LinkTuple*
 OlsrState::FindSymLinkTuple (Ipv4Address const &ifaceAddr, Time now)
 {
   for (LinkSet::iterator it = m_linkSet.begin ();
        it != m_linkSet.end (); it++)
     {
       if (it->neighborIfaceAddr == ifaceAddr)
         {
           if (it->symTime > now)
             {
               return &(*it);
             }
           else
             {
               break;
             }
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseLinkTuple (const LinkTuple &tuple)
 {
   for (LinkSet::iterator it = m_linkSet.begin ();
        it != m_linkSet.end (); it++)
     {
       if (*it == tuple)
         {
           m_linkSet.erase (it);
           break;
         }
     }
 }
 
 LinkTuple&
 OlsrState::InsertLinkTuple (LinkTuple const &tuple)
 {
   m_linkSet.push_back (tuple);
   return m_linkSet.back ();
 }
 
 /********** Topology Set Manipulation **********/
 
 TopologyTuple*
 OlsrState::FindTopologyTuple (Ipv4Address const &destAddr,
                               Ipv4Address const &lastAddr)
 {
   for (TopologySet::iterator it = m_topologySet.begin ();
        it != m_topologySet.end (); it++)
     {
       if (it->destAddr == destAddr && it->lastAddr == lastAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 TopologyTuple*
 OlsrState::FindNewerTopologyTuple (Ipv4Address const & lastAddr, uint16_t ansn)
 {
   for (TopologySet::iterator it = m_topologySet.begin ();
        it != m_topologySet.end (); it++)
     {
       if (it->lastAddr == lastAddr && it->sequenceNumber > ansn)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseTopologyTuple (const TopologyTuple &tuple)
 {
   for (TopologySet::iterator it = m_topologySet.begin ();
        it != m_topologySet.end (); it++)
     {
       if (*it == tuple)
         {
           m_topologySet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::EraseOlderTopologyTuples (const Ipv4Address &lastAddr, uint16_t ansn)
 {
   for (TopologySet::iterator it = m_topologySet.begin ();
        it != m_topologySet.end (); )
     {
       if (it->lastAddr == lastAddr && it->sequenceNumber < ansn)
         {
           it = m_topologySet.erase (it);
         }
       else
         {
           it++;
         }
     }
 }
 
 void
 OlsrState::InsertTopologyTuple (TopologyTuple const &tuple)
 {
   m_topologySet.push_back (tuple);
 }
 
 /********** Interface Association Set Manipulation **********/
 
 IfaceAssocTuple*
 OlsrState::FindIfaceAssocTuple (Ipv4Address const &ifaceAddr)
 {
   for (IfaceAssocSet::iterator it = m_ifaceAssocSet.begin ();
        it != m_ifaceAssocSet.end (); it++)
     {
       if (it->ifaceAddr == ifaceAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 const IfaceAssocTuple*
 OlsrState::FindIfaceAssocTuple (Ipv4Address const &ifaceAddr) const
 {
   for (IfaceAssocSet::const_iterator it = m_ifaceAssocSet.begin ();
        it != m_ifaceAssocSet.end (); it++)
     {
       if (it->ifaceAddr == ifaceAddr)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseIfaceAssocTuple (const IfaceAssocTuple &tuple)
 {
   for (IfaceAssocSet::iterator it = m_ifaceAssocSet.begin ();
        it != m_ifaceAssocSet.end (); it++)
     {
       if (*it == tuple)
         {
           m_ifaceAssocSet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::InsertIfaceAssocTuple (const IfaceAssocTuple &tuple)
 {
   m_ifaceAssocSet.push_back (tuple);
 }
 
 std::vector<Ipv4Address>
 OlsrState::FindNeighborInterfaces (const Ipv4Address &neighborMainAddr) const
 {
   std::vector<Ipv4Address> retval;
   for (IfaceAssocSet::const_iterator it = m_ifaceAssocSet.begin ();
        it != m_ifaceAssocSet.end (); it++)
     {
       if (it->mainAddr == neighborMainAddr)
         {
           retval.push_back (it->ifaceAddr);
         }
     }
   return retval;
 }
 
 /********** Host-Network Association Set Manipulation **********/
 
 AssociationTuple*
 OlsrState::FindAssociationTuple (const Ipv4Address &gatewayAddr, const Ipv4Address &networkAddr, const Ipv4Mask &netmask)
 {
   for (AssociationSet::iterator it = m_associationSet.begin ();
        it != m_associationSet.end (); it++)
     {
       if (it->gatewayAddr == gatewayAddr and it->networkAddr == networkAddr and it->netmask == netmask)
         {
           return &(*it);
         }
     }
   return NULL;
 }
 
 void
 OlsrState::EraseAssociationTuple (const AssociationTuple &tuple)
 {
   for (AssociationSet::iterator it = m_associationSet.begin ();
        it != m_associationSet.end (); it++)
     {
       if (*it == tuple)
         {
           m_associationSet.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::InsertAssociationTuple (const AssociationTuple &tuple)
 {
   m_associationSet.push_back (tuple);
 }
 
 void
 OlsrState::EraseAssociation (const Association &tuple)
 {
   for (Associations::iterator it = m_associations.begin ();
        it != m_associations.end (); it++)
     {
       if (*it == tuple)
         {
           m_associations.erase (it);
           break;
         }
     }
 }
 
 void
 OlsrState::InsertAssociation (const Association &tuple)
 {
   m_associations.push_back (tuple);
 }
 
 }
 }  // namespace olsr, ns3
